# ![](https://cnsc.uit.edu.vn/files/a5f4b16e6021acf91fc92de2f292a7a1/Challend.png)

# A Letter I Send Love To You

## Solution:
- Sau khi tải file .zip về và giải nén ra, ta thấy 100 file excel .csv mà mỗi file có đúng 2 cột.
- Nghĩ ngay đến scatter và matplotlib.pyplot:

# ![](https://scontent.fsgn5-3.fna.fbcdn.net/v/t1.15752-9/370351803_279252471739671_6168032560937470069_n.png?_nc_cat=104&ccb=1-7&_nc_sid=8cd0a2&_nc_ohc=5dKhVDsxoYkAX8hBkiU&_nc_ht=scontent.fsgn5-3.fna&oh=03_AdRbWOFCN-iCA2EnX7JDHGA6TkeSwdTUmVwOI2dNOhA4Eg&oe=6552DCBB)

- Cho i chạy từ 1 đến 100, trong mỗi file .csv, lấy dữ liệu cột 0 và 1 chuyển thành mảng.
- Đồng thời vẽ biểu đồ tọa độ cho từng file.
- Kết quả:
# ![](https://scontent.fsgn5-11.fna.fbcdn.net/v/t1.15752-9/368584269_734518845184994_6295880807797623862_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_ohc=rJjbZwpdoR4AX_gyilZ&_nc_ht=scontent.fsgn5-11.fna&oh=03_AdR7HyKgxbL_eezT6g3OiVH6afcwgyKqNn0iI9Hn4oPsAA&oe=6552EB96)

- Giảm height lại:
# ![](https://scontent.fsgn5-2.fna.fbcdn.net/v/t1.15752-9/387419558_1024682962112009_3182335570065611275_n.png?_nc_cat=105&ccb=1-7&_nc_sid=8cd0a2&_nc_ohc=sZJtTIWjfoUAX__WLvE&_nc_ht=scontent.fsgn5-2.fna&oh=03_AdRXD26k8QwLsVzb-dxpe9u8AecSBfMz7lUzkfwT2T7FMg&oe=6552C518)

## Flag: W1{te4m_cut3}